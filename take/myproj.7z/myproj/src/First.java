

abstract class  First
{
public long add(long a,int b)
{
	return a+b;
}


public double add(double a,int b)
{
	return a*b;
}







}