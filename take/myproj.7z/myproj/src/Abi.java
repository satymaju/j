
public class Abi {

int add(int a,int b)
{
	return(a+b);
}
}
