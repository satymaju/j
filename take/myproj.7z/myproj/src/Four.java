
public  class Four extends First {
	
	public long add(long a,int b)
	{
		return a-b;
	}

}
