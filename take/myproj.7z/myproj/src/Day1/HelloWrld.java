package Day1;

import java.util.*;




public class HelloWrld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=1;
		System.out.print("Hello Worldd");
		//Scanner c=new Scanner(System.in);
			checkeven(num);
				
	}

	static void checkeven(int num)
	{
		if(num%2==0)
			System.out.print("\nEven");
		else
			System.out.print("\nOdd");
	}


}
