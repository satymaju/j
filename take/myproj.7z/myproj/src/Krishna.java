
public class Krishna {

	public static void main(String[] args)
	{
	

		
		
		Four f=new First();
	
		

		
		
		
		
		
		
		
		
		
	}



	
}
