package com.capgemini.lesson14.mock;

public class User {
String username, password;
}
